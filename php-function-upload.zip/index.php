<?php
/**
 * Yandex Cloud Functions handler for the task-list page.
 *
 * Deployment archive must contain:
 *   index.php
 *   page-template.php
 *
 * IMPORTANT:
 * This demo stores state in /tmp. Cloud Functions local storage is temporary
 * and is not shared reliably between function instances. For durable shared
 * storage, connect Yandex Object Storage or YDB.
 */
function handler($event, $context)
{
    $storageFile = sys_get_temp_dir() . '/tasks_state.json';

    // API Gateway passes the HTTP method in httpMethod.
    $method = strtoupper(
        $event['httpMethod']
        ?? ($event['requestContext']['http']['method'] ?? 'GET')
    );

    if ($method === 'POST') {
        $body = $event['body'] ?? '';

        if (!empty($event['isBase64Encoded'])) {
            $body = base64_decode($body, true);
            if ($body === false) {
                $body = '';
            }
        }

        $state = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($state)) {
            return [
                'statusCode' => 400,
                'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
                'isBase64Encoded' => false,
                'body' => json_encode([
                    'status' => 'error',
                    'message' => 'Invalid JSON'
                ])
            ];
        }

        $written = file_put_contents(
            $storageFile,
            json_encode($state, JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );

        return [
            'statusCode' => $written === false ? 500 : 200,
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'isBase64Encoded' => false,
            'body' => json_encode([
                'status' => $written === false ? 'error' : 'success'
            ])
        ];
    }

    if ($method !== 'GET') {
        return [
            'statusCode' => 405,
            'headers' => [
                'Content-Type' => 'application/json; charset=utf-8',
                'Allow' => 'GET, POST'
            ],
            'isBase64Encoded' => false,
            'body' => json_encode([
                'status' => 'error',
                'message' => 'Method not allowed'
            ])
        ];
    }

    $initialState = [];
    if (is_file($storageFile)) {
        $stored = file_get_contents($storageFile);
        $decoded = json_decode($stored ?: '{}', true);

        if (is_array($decoded)) {
            $initialState = $decoded;
        }
    }

    $GLOBALS['TASKS_INITIAL_STATE'] = $initialState;

    ob_start();
    include __DIR__ . '/page-template.php';
    $html = ob_get_clean();

    return [
        'statusCode' => 200,
        'headers' => ['Content-Type' => 'text/html; charset=utf-8'],
        'isBase64Encoded' => false,
        'body' => $html
    ];
}
